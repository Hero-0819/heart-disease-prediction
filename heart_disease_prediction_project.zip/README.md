# Heart Disease Prediction

This project uses machine learning to predict the likelihood of heart disease based on patient medical data.  
It was built using **Logistic Regression** and the **Scikit-learn** machine learning library.

## Dataset
The dataset contains medical features such as:
- Age
- Sex
- Chest pain type
- Blood pressure
- Cholesterol levels
- And more...

The target variable is:
- `1` = Heart disease present
- `0` = No heart disease

## Project Steps
1. Data loading and inspection
2. Preprocessing (scaling numeric data, encoding categorical data)
3. Splitting into training and testing sets
4. Training the Logistic Regression model
5. Evaluation (Accuracy, Precision, Recall, F1-score)

## Results
- Accuracy: **81%**
- The model performs well in predicting heart disease for both positive and negative cases.

## Run This Project in Google Colab
Click the badge below to open and run the notebook in Google Colab:

[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/YourUsername/heart-disease-prediction/blob/main/heart_disease_project.ipynb)

## Requirements
- pandas
- numpy
- scikit-learn
